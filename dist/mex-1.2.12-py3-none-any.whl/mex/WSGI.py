from mex.MexAPI import app, Start_Mex_Api


mex_api = Start_Mex_Api()
application = app
